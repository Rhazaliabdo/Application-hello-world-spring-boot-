package com.CIGL.RhazaliAbderrazzaqHelloWorldProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RhazaliAbderrazzaqHelloWorldProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(RhazaliAbderrazzaqHelloWorldProjectApplication.class, args);
		System.out.println("\nHello world !!!!!!!!");
	}

}
